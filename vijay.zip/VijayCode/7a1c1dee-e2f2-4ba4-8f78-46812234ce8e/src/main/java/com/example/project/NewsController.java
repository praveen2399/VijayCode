package com.example.project;







public class NewsController {


	public  News getNews() throws Exception{
	return null;
	}
	
}
