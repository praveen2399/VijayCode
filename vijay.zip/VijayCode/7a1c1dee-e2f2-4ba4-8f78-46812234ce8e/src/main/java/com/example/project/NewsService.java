package com.example.project;




public class NewsService {
	


	
	public News getTopStories() {
		return null;
	}
}
