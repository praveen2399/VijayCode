package com.example.project;




public class SpringSecurityConfig  {



}
