package com.example.project;



import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {



}
