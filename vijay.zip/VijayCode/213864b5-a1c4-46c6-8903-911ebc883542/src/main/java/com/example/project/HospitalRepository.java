package com.example.project;



public interface HospitalRepository {

}
