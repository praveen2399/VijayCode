package com.example.project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HospitalService {

	@Autowired
	private HospitalRepository hospitalRepository;

	public List<Hospital> getAllHospitals() {

		List<HospitalInfo> hospList = hospitalRepository.findAll();

		List<Hospital> responseList = hospList.stream().map(a -> {
			Hospital obj = new Hospital();
			obj.setId(a.getId());
			obj.setName(a.getName());
			obj.setRating(Double.parseDouble(a.getRating()));
			obj.setCity(a.getCity());
			return obj;

		}).collect(Collectors.toList());

		return responseList;
	}

	public Hospital getHospital(int id) {

		HospitalInfo resp = hospitalRepository.findById(id);

		return new Hospital(resp.getId(), resp.getName(), resp.getCity(), 
				Double.parseDouble(resp.getRating()));
	}

	public void addHospital(Hospital hospital) {
		
		HospitalInfo hosp = new HospitalInfo();
		hosp.setId(hospital.getId());
		hosp.setName(hospital.getName());
		hosp.setRating(Double.toString(hospital.getRating()));
		hosp.setCity(hospital.getCity());
		
		hospitalRepository.save(hosp);

	}

	public void updateHospital(Hospital hospital) {
		
		HospitalInfo hosp = hospitalRepository.findById(hospital.getId());
		
		hosp.setCity(hospital.getCity());
		hosp.setName(hospital.getName());
		hosp.setRating(hospital.getName());
		
		hospitalRepository.save(hosp);

	}

	public void deleteHospital(Hospital hospital) {
		
HospitalInfo hosp = hospitalRepository.findById(hospital.getId());
		
		hosp.setCity(hospital.getCity());
		hosp.setName(hospital.getName());
		hosp.setRating(hospital.getName());
		
		hospitalRepository.delete(hosp);

	}
}
