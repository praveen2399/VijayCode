package com.example.project;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "HOSPITALINFO")
public class HospitalInfo {
	
	 @Id
	  private Integer id;
	  private String name;
	  private String rating;
	  private String city;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "HospitalInfo [id=" + id + ", name=" + name + ", rating=" + rating + ", city=" + city + "]";
	}
	public HospitalInfo(Integer id, String name, String rating, String city) {
		super();
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.city = city;
	}
	public HospitalInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	  
	  
	

}
