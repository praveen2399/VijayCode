package com.example.project;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class NewsService {
	



	public List<News> getTopStories() {
		
		List<News> newsList = new ArrayList<News>();
		
	
		newsList.add(new News("Title1", "Section2"));
		newsList.add(new News("Title2", "Section3"));
		newsList.add(new News("Title3", "Section4"));
		
		return newsList;
	}
}
