package com.example.project;

public class News {
private String title;
private String section;
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getSection() {
	return section;
}
public void setSection(String section) {
	this.section = section;
}
public News(String title, String section) {
	super();
	this.title = title;
	this.section = section;
}


}
