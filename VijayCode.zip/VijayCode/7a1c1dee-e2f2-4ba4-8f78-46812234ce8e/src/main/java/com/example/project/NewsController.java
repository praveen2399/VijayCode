package com.example.project;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NewsController {
	
	@Autowired
	NewsService service;

	@GetMapping(value = "/api/news/topstories")
	public  Results getNews() throws Exception{
		
		Results results= new Results();
		results.setResults(service.getTopStories());
		results.setSection("section");
	return results;
	}
	
}
