package com.example.project;

import java.util.List;

public class Results {
	
	List<News> results;
	String section;

	public List<News> getResults() {
		return results;
	}

	public void setResults(List<News> results) {
		this.results = results;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}
	
	
	

}
