package com.example.project;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class BookSearchController {
	
	
	@GetMapping(value = "/booksearch")
	public ResponseEntity<String> getBook()
	{
		RestTemplate rest = new RestTemplate();
		
		return new ResponseEntity<String>("Success",HttpStatus.OK);
		
		 
	}

}
